const susi = document.getElementsByClassName("signUp-signIn")[0];

susi.onclick=()=>{
    console.log("HOHOHO");
    location.reload();
}


